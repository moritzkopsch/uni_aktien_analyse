<?php
// PHPMailer einbinden – Pfad an dein Verzeichnis anpassen
require __DIR__ . '/../phpmailer/PHPMailer-master/src/Exception.php';
require __DIR__ . '/../phpmailer/PHPMailer-master/src/PHPMailer.php';
require __DIR__ . '/../phpmailer/PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Formulardaten
$to = $_POST['to'] ?? '';
$subject = $_POST['subject'] ?? '';
$message = $_POST['message'] ?? '';

if (!$to || !$subject || !$message) {
    die("Bitte alle Felder ausfüllen.");
}

$mail = new PHPMailer(true);

try {
    //Server-Einstellungen
    $mail->isSMTP();
    $mail->Host       = 'uniprojektaktien.online';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'verify@uniprojektaktien.online'; // dein SMTP-Username
    $mail->Password   = 'C4dL8Mtpwf2'; // Passwort
    $mail->SMTPSecure = 'ssl';
    $mail->Port       = 465;

    //Empfänger
    $mail->setFrom('valid@pushflow.de', 'Test Sender');
    $mail->addAddress($to);

    //Inhalt
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = nl2br($message);
    $mail->AltBody = $message;

    $mail->send();
    echo "Email erfolgreich gesendet an $to";
} catch (Exception $e) {
    echo "Fehler beim Senden der Email: {$mail->ErrorInfo}";
}
