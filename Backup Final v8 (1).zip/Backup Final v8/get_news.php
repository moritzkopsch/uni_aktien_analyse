<?php
// schutz: datei nich 2 mal laden
if (defined('GET_NEWS_PHP_LOADED')) { return; }
define('GET_NEWS_PHP_LOADED', true);

if (!function_exists('loadNewsAuto')) {
    function loadNewsAuto(): array {
        // db daten – GENAU so wie in cPanel (gross/klein wichtig!)
        $dbHost    = 'localhost';
        $dbPort    = 3306;
        $dbName    = 'pushgobt_News';           // pruef genau die schreibweis im cPanel!
        $dbUser    = 'pushgobt_admin2';
        $dbPass    = 'UNiProjektBeiLucke2025';
        $dbCharset = 'utf8mb4';

        // pdo aufbau
        $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset={$dbCharset}";
        try {
            $pdo = new PDO($dsn, $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (Throwable $e) {
            throw new RuntimeException('db verbinung fehlgeschlagen: '.$e->getMessage(), 0, $e);
        }

        // tabellen name auto finden (verschiedene schreibweisen)
        // wir holen erst alle tabellen und mappen sie lower->original
        $stmt = $pdo->prepare("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ?");
        $stmt->execute([$dbName]);
        $allTables = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $lowerMap = []; // lower => original
        foreach ($allTables as $t) { $lowerMap[strtolower($t)] = $t; }

        // kandidaten die wir probiren
        $candidates = [
            'news_tamplate', 'news_template', 'news_templates',
            'news', 'news_items', 'news_table'
        ];

        $table = null;
        foreach ($candidates as $cand) {
            if (isset($lowerMap[$cand])) { $table = $lowerMap[$cand]; break; }
        }

        // wenn nix gefunden, nimm die erste tabelle die mit 'news' anfängt
        if (!$table) {
            $stmt = $pdo->prepare("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
                                   WHERE TABLE_SCHEMA = ? AND LOWER(TABLE_NAME) LIKE 'news%' 
                                   ORDER BY TABLE_NAME LIMIT 1");
            $stmt->execute([$dbName]);
            $table = $stmt->fetchColumn() ?: null;
        }

        if (!$table) {
            // keine passende tabelle gefunden -> klare fehlermeldung mit liste
            $list = $allTables ? implode(', ', $allTables) : '(keine tabellen gefunden)';
            throw new RuntimeException("keine news tabelle gefnden in DB `{$dbName}`. vorhandene tabellen: ".$list);
        }

        // spalten auto erkennen (headline/title, body/content/teaser)
        $stmt = $pdo->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=?");
        $stmt->execute([$dbName, $table]);
        $cols = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if (!$cols) {
            throw new RuntimeException("tabelle `{$table}` hat keine spalten? check mal im phpMyAdmin.");
        }

        $colsLower = array_map('strtolower', $cols);

        // helper: finde die erste passende spalte aus einer liste
        $findCol = function(array $choices) use ($cols, $colsLower) {
            foreach ($choices as $ch) {
                $i = array_search($ch, $colsLower, true);
                if ($i !== false) return $cols[$i];
            }
            return null;
        };

        // id/title/body kandidaten
        $colId    = $findCol(['id','news_id','nid']);
        $colTitle = $findCol(['headline','title','heading','name']);
        $colBody  = $findCol(['body','content','text','teaser','description','desc']);

        // fallbacks wen nix passt (nich schön, aber funz)
        if (!$colId)    { $colId    = $cols[0]; }
        if (!$colTitle) { $colTitle = $cols[1] ?? $cols[0]; }
        if (!$colBody)  { $colBody  = $cols[2] ?? $cols[1] ?? $cols[0]; }

        // zufal anzahl 1..5 mit gewichtung
        $pick  = random_int(1, 100);
        $count = ($pick <= 15) ? 1 : (($pick <= 50) ? 2 : (($pick <= 80) ? 3 : (($pick <= 95) ? 4 : 5)));
        $limit = (int)$count;

        // query bau mit backticks (wegen sonderzeichen/gross-klein)
        $sql = "SELECT `{$colId}`    AS id,
                       `{$colTitle}` AS headline,
                       `{$colBody}`  AS body
                FROM `{$table}`
                ORDER BY RAND()
                LIMIT {$limit}";

        try {
            $rows = $pdo->query($sql)->fetchAll();
        } catch (Throwable $e) {
            throw new RuntimeException('db abfarge fehlgeschlagen (`'.$table.'`): '.$e->getMessage(), 0, $e);
        }

        // normalizirung der ausgabe
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id'       => (int)($r['id'] ?? 0),
                'headline' => (string)($r['headline'] ?? ''),
                'body'     => (string)($r['body'] ?? ''),
            ];
        }
        return $out;
    }
}
