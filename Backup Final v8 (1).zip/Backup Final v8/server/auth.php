<?php
require_once 'config.php';

// PHPMailer einbinden
require __DIR__ . '/../../phpmailer/PHPMailer-master/src/Exception.php';
require __DIR__ . '/../../phpmailer/PHPMailer-master/src/PHPMailer.php';
require __DIR__ . '/../../phpmailer/PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Funktion zum Senden der Verifizierungs-E-Mail
function sendVerificationEmail($email, $code) {
    $mail = new PHPMailer(true);
    
    try {
        // Server-Einstellungen
        $mail->isSMTP();
        $mail->Host       = 'uniprojektaktien.online';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'verify@uniprojektaktien.online';
        $mail->Password   = 'C4dL8Mtpwf2';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // Empfänger
        $mail->setFrom('verify@uniprojektaktien.online', 'UniAktiending Verifizierung');
        $mail->addAddress($email);

        // Inhalt
        $mail->isHTML(true);
        $mail->Subject = 'UniAktiending - E-Mail Verifizierung';
        $mail->Body    = "
            <h2>Willkommen bei UniAktiending!</h2>
            <p>Vielen Dank für Ihre Registrierung. Um Ihr Konto zu aktivieren, geben Sie bitte den folgenden Verifizierungscode ein:</p>
            <h3 style='color: #90EE90; font-size: 24px; letter-spacing: 3px;'>$code</h3>
            <p>Dieser Code ist 24 Stunden gültig.</p>
            <p>Falls Sie sich nicht bei UniAktiending registriert haben, ignorieren Sie diese E-Mail.</p>
        ";
        $mail->AltBody = "Ihr Verifizierungscode für UniAktiending: $code";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("E-Mail Fehler: " . $mail->ErrorInfo);
        return false;
    }
}

// Handle GET requests (for check_session)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    if ($action === 'check_session') {
        if (isset($_SESSION['user_id'])) {
            // Prüfe ob User verifiziert ist
            $stmt = $pdo->prepare("SELECT is_verified FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            echo json_encode([
                'success' => true, 
                'user' => [
                    'id' => $_SESSION['user_id'],
                    'email' => $_SESSION['user_email'] ?? '',
                    'is_verified' => $user['is_verified'] ?? 0
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Nicht angemeldet']);
        }
        exit;
    }
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'register') {
        // KORREKTUR: Verwende 'email' statt 'username'
        $email = $_POST['email'] ?? $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($email) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'E-Mail und Passwort erforderlich']);
            exit;
        }
        
        // Validiere E-Mail Format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Ungültiges E-Mail Format']);
            exit;
        }
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Generiere 5-stelligen Verifizierungscode
        $verificationCode = str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT);
        
        try {
            // Prüfe ob E-Mail bereits existiert
            $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $checkStmt->execute([$email]);
            if ($checkStmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'E-Mail bereits registriert']);
                exit;
            }
            
            // Erstelle neuen User
            $stmt = $pdo->prepare("INSERT INTO users (email, password, is_verified, email_code) VALUES (?, ?, 0, ?)");
            $stmt->execute([$email, $hashedPassword, $verificationCode]);
            
            // Sende Verifizierungs-E-Mail
            if (sendVerificationEmail($email, $verificationCode)) {
                echo json_encode([
                    'success' => true, 
                    'message' => 'Registrierung erfolgreich! Prüfen Sie Ihre E-Mails für den Verifizierungscode.',
                    'redirect' => 'sendemail.html?email=' . urlencode($email)
                ]);
            } else {
                // Lösche User wenn E-Mail nicht gesendet werden konnte
                $deleteStmt = $pdo->prepare("DELETE FROM users WHERE email = ?");
                $deleteStmt->execute([$email]);
                echo json_encode(['success' => false, 'message' => 'Fehler beim Senden der Verifizierungs-E-Mail']);
            }
            
        } catch(PDOException $e) {
            if ($e->getCode() == 23000) { // Duplicate entry
                echo json_encode(['success' => false, 'message' => 'E-Mail bereits registriert']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Registrierung fehlgeschlagen: ' . $e->getMessage()]);
            }
        }
    }
    
    if ($action === 'verify_email') {
        $email = $_POST['email'] ?? '';
        $code = $_POST['code'] ?? '';
        
        if (empty($email) || empty($code)) {
            echo json_encode(['success' => false, 'message' => 'E-Mail und Code erforderlich']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND email_code = ? AND is_verified = 0");
            $stmt->execute([$email, $code]);
            $user = $stmt->fetch();
            
            if ($user) {
                // Prüfe ob Code nicht älter als 24 Stunden ist
                $createdAt = new DateTime($user['created_at']);
                $now = new DateTime();
                $diff = $now->diff($createdAt);
                
                if ($diff->days > 0 || $diff->h > 24) {
                    echo json_encode(['success' => false, 'message' => 'Verifizierungscode ist abgelaufen']);
                    exit;
                }
                
                // Verifiziere User
                $updateStmt = $pdo->prepare("UPDATE users SET is_verified = 1, verified_at = CURRENT_TIMESTAMP, email_code = NULL WHERE id = ?");
                $updateStmt->execute([$user['id']]);
                
                echo json_encode(['success' => true, 'message' => 'E-Mail erfolgreich verifiziert! Sie können sich jetzt anmelden.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Ungültiger Verifizierungscode']);
            }
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Verifizierung fehlgeschlagen: ' . $e->getMessage()]);
        }
    }
    
    if ($action === 'login') {
        // KORREKTUR: Verwende 'email' statt 'username'
        $email = $_POST['email'] ?? $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($email) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'E-Mail und Passwort erforderlich']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                if ($user['is_verified'] == 0) {
                    echo json_encode(['success' => false, 'message' => 'Bitte verifizieren Sie zuerst Ihre E-Mail-Adresse']);
                    exit;
                }
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_email'] = $user['email'];
                echo json_encode([
                    'success' => true, 
                    'user' => [
                        'id' => $user['id'],
                        'email' => $user['email'],
                        'is_verified' => $user['is_verified']
                    ]
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Ungültige Anmeldedaten']);
            }
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Login fehlgeschlagen: ' . $e->getMessage()]);
        }
    }
    
    if ($action === 'logout') {
        session_destroy();
        echo json_encode(['success' => true, 'message' => 'Erfolgreich abgemeldet']);
    }
}
?>