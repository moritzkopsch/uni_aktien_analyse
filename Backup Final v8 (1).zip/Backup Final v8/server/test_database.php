<?php
require_once 'config.php';

try {
    // Teste Verbindung
    echo "<h2>Datenbankverbindung Test</h2>";
    echo "✅ Verbindung erfolgreich<br><br>";
    
    // Zeige alle Tabellen
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<h3>Vorhandene Tabellen:</h3>";
    foreach($tables as $table) {
        echo "📋 $table<br>";
    }
    echo "<br>";
    
    // Zeige Anzahl der Aktien
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM stocks");
    $count = $stmt->fetch()['count'];
    echo "<h3>Aktien in der Datenbank:</h3>";
    echo "📊 Anzahl: $count<br><br>";
    
    // Zeige erste 10 Aktien
    $stmt = $pdo->query("SELECT * FROM stocks LIMIT 10");
    $stocks = $stmt->fetchAll();
    
    echo "<h3>Erste 10 Aktien:</h3>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>Symbol</th><th>Name</th><th>Sektor</th><th>Land</th></tr>";
    foreach($stocks as $stock) {
        echo "<tr>";
        echo "<td>{$stock['id']}</td>";
        echo "<td>{$stock['symbol']}</td>";
        echo "<td>{$stock['name']}</td>";
        echo "<td>{$stock['sector']}</td>";
        echo "<td>{$stock['country']}</td>";
        echo "</tr>";
    }
    echo "</table><br>";
    
    // Teste Suche nach 'A'
    echo "<h3>Test: Suche nach 'A'</h3>";
    $stmt = $pdo->prepare("SELECT * FROM stocks WHERE symbol LIKE ? OR name LIKE ? LIMIT 5");
    $stmt->execute(['A%', '%A%']);
    $results = $stmt->fetchAll();
    
    echo "Gefundene Ergebnisse: " . count($results) . "<br>";
    foreach($results as $result) {
        echo "🔍 {$result['symbol']} - {$result['name']}<br>";
    }
    
} catch(PDOException $e) {
    echo "❌ Fehler: " . $e->getMessage();
}
?>