<?php
require_once 'config.php';

try {
    // Erstelle die stocks Tabelle
    $sql = "CREATE TABLE IF NOT EXISTS stocks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        symbol VARCHAR(20) NOT NULL UNIQUE,
        name VARCHAR(255) NOT NULL,
        sector VARCHAR(100),
        country VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    
    // Definiere die 100 Aktien mit Namen
    $stocks = [
        ['AAPL', 'Apple Inc.', 'Technology', 'USA'],
        ['MSFT', 'Microsoft Corporation', 'Technology', 'USA'],
        ['AMZN', 'Amazon.com Inc.', 'E-Commerce', 'USA'],
        ['GOOGL', 'Alphabet Inc.', 'Technology', 'USA'],
        ['META', 'Meta Platforms Inc.', 'Technology', 'USA'],
        ['NVDA', 'NVIDIA Corporation', 'Technology', 'USA'],
        ['TSLA', 'Tesla Inc.', 'Automotive', 'USA'],
        ['JPM', 'JPMorgan Chase & Co.', 'Banking', 'USA'],
        ['BAC', 'Bank of America Corp.', 'Banking', 'USA'],
        ['WFC', 'Wells Fargo & Company', 'Banking', 'USA'],
        ['C', 'Citigroup Inc.', 'Banking', 'USA'],
        ['GS', 'Goldman Sachs Group Inc.', 'Banking', 'USA'],
        ['MS', 'Morgan Stanley', 'Banking', 'USA'],
        ['V', 'Visa Inc.', 'Financial Services', 'USA'],
        ['MA', 'Mastercard Inc.', 'Financial Services', 'USA'],
        ['PYPL', 'PayPal Holdings Inc.', 'Financial Services', 'USA'],
        ['SQ', 'Block Inc.', 'Financial Services', 'USA'],
        ['COIN', 'Coinbase Global Inc.', 'Financial Services', 'USA'],
        ['BRK.B', 'Berkshire Hathaway Inc.', 'Conglomerate', 'USA'],
        ['UNH', 'UnitedHealth Group Inc.', 'Healthcare', 'USA'],
        ['JNJ', 'Johnson & Johnson', 'Healthcare', 'USA'],
        ['PFE', 'Pfizer Inc.', 'Healthcare', 'USA'],
        ['MRK', 'Merck & Co. Inc.', 'Healthcare', 'USA'],
        ['ABBV', 'AbbVie Inc.', 'Healthcare', 'USA'],
        ['LLY', 'Eli Lilly and Company', 'Healthcare', 'USA'],
        ['BMY', 'Bristol Myers Squibb Co.', 'Healthcare', 'USA'],
        ['CVS', 'CVS Health Corporation', 'Healthcare', 'USA'],
        ['TMO', 'Thermo Fisher Scientific Inc.', 'Healthcare', 'USA'],
        ['HD', 'Home Depot Inc.', 'Retail', 'USA'],
        ['LOW', 'Lowe\'s Companies Inc.', 'Retail', 'USA'],
        ['COST', 'Costco Wholesale Corporation', 'Retail', 'USA'],
        ['WMT', 'Walmart Inc.', 'Retail', 'USA'],
        ['TGT', 'Target Corporation', 'Retail', 'USA'],
        ['SBUX', 'Starbucks Corporation', 'Consumer Services', 'USA'],
        ['MCD', 'McDonald\'s Corporation', 'Consumer Services', 'USA'],
        ['KO', 'Coca-Cola Company', 'Consumer Goods', 'USA'],
        ['PEP', 'PepsiCo Inc.', 'Consumer Goods', 'USA'],
        ['KHC', 'Kraft Heinz Company', 'Consumer Goods', 'USA'],
        ['PG', 'Procter & Gamble Co.', 'Consumer Goods', 'USA'],
        ['UL', 'Unilever PLC', 'Consumer Goods', 'UK'],
        ['CL', 'Colgate-Palmolive Company', 'Consumer Goods', 'USA'],
        ['NKE', 'Nike Inc.', 'Consumer Goods', 'USA'],
        ['LULU', 'Lululemon Athletica Inc.', 'Consumer Goods', 'Canada'],
        ['ADDYY', 'Adidas AG', 'Consumer Goods', 'Germany'],
        ['DIS', 'Walt Disney Company', 'Entertainment', 'USA'],
        ['NFLX', 'Netflix Inc.', 'Entertainment', 'USA'],
        ['CMCSA', 'Comcast Corporation', 'Entertainment', 'USA'],
        ['PARA', 'Paramount Global', 'Entertainment', 'USA'],
        ['WBD', 'Warner Bros. Discovery Inc.', 'Entertainment', 'USA'],
        ['SONY', 'Sony Group Corporation', 'Entertainment', 'Japan'],
        ['INTL', 'Intel Corporation', 'Technology', 'USA'],
        ['AMD', 'Advanced Micro Devices Inc.', 'Technology', 'USA'],
        ['QCOM', 'Qualcomm Inc.', 'Technology', 'USA'],
        ['MU', 'Micron Technology Inc.', 'Technology', 'USA'],
        ['AVGO', 'Broadcom Inc.', 'Technology', 'USA'],
        ['TXN', 'Texas Instruments Inc.', 'Technology', 'USA'],
        ['ASML', 'ASML Holding N.V.', 'Technology', 'Netherlands'],
        ['TSM', 'Taiwan Semiconductor Mfg. Co.', 'Technology', 'Taiwan'],
        ['SHOP', 'Shopify Inc.', 'E-Commerce', 'Canada'],
        ['MELI', 'MercadoLibre Inc.', 'E-Commerce', 'Argentina'],
        ['SE', 'Sea Limited', 'E-Commerce', 'Singapore'],
        ['ROKU', 'Roku Inc.', 'Technology', 'USA'],
        ['SNAP', 'Snap Inc.', 'Technology', 'USA'],
        ['BABA', 'Alibaba Group Holding Ltd.', 'E-Commerce', 'China'],
        ['JD', 'JD.com Inc.', 'E-Commerce', 'China'],
        ['PDD', 'PDD Holdings Inc.', 'E-Commerce', 'China'],
        ['BIDU', 'Baidu Inc.', 'Technology', 'China'],
        ['NTES', 'NetEase Inc.', 'Technology', 'China'],
        ['TCEHY', 'Tencent Holdings Ltd.', 'Technology', 'China'],
        ['HDB', 'HDFC Bank Limited', 'Banking', 'India'],
        ['IBN', 'ICICI Bank Limited', 'Banking', 'India'],
        ['INFY', 'Infosys Limited', 'Technology', 'India'],
        ['RELIANCE.NS', 'Reliance Industries Ltd.', 'Energy', 'India'],
        ['RIO', 'Rio Tinto Group', 'Mining', 'Australia'],
        ['BHP', 'BHP Group Limited', 'Mining', 'Australia'],
        ['VALE', 'Vale S.A.', 'Mining', 'Brazil'],
        ['FCX', 'Freeport-McMoRan Inc.', 'Mining', 'USA'],
        ['NEM', 'Newmont Corporation', 'Mining', 'USA'],
        ['GOLD', 'Barrick Gold Corporation', 'Mining', 'Canada'],
        ['XOM', 'Exxon Mobil Corporation', 'Energy', 'USA'],
        ['CVX', 'Chevron Corporation', 'Energy', 'USA'],
        ['COP', 'ConocoPhillips', 'Energy', 'USA'],
        ['BP', 'BP p.l.c.', 'Energy', 'UK'],
        ['SHEL', 'Shell plc', 'Energy', 'UK'],
        ['TOT', 'TotalEnergies SE', 'Energy', 'France'],
        ['ENB', 'Enbridge Inc.', 'Energy', 'Canada'],
        ['EQNR', 'Equinor ASA', 'Energy', 'Norway'],
        ['PLTR', 'Palantir Technologies Inc.', 'Technology', 'USA'],
        ['SNOW', 'Snowflake Inc.', 'Technology', 'USA'],
        ['CRWD', 'CrowdStrike Holdings Inc.', 'Technology', 'USA'],
        ['ZS', 'Zscaler Inc.', 'Technology', 'USA'],
        ['PANW', 'Palo Alto Networks Inc.', 'Technology', 'USA'],
        ['DDOG', 'Datadog Inc.', 'Technology', 'USA'],
        ['MDB', 'MongoDB Inc.', 'Technology', 'USA'],
        ['NET', 'Cloudflare Inc.', 'Technology', 'USA'],
        ['U', 'Unity Software Inc.', 'Technology', 'USA'],
        ['ROBLOX', 'Roblox Corporation', 'Technology', 'USA'],
        ['DKNG', 'DraftKings Inc.', 'Entertainment', 'USA'],
        ['SPOT', 'Spotify Technology S.A.', 'Entertainment', 'Sweden'],
        ['RVSN', 'Rail Vision Ltd.', 'Technology', 'Israel']
    ];
    
    // Lösche alte Daten falls vorhanden
    $pdo->exec("DELETE FROM stocks");
    
    // Füge alle Aktien ein
    $stmt = $pdo->prepare("INSERT INTO stocks (symbol, name, sector, country) VALUES (?, ?, ?, ?)");
    
    foreach ($stocks as $stock) {
        $stmt->execute($stock);
    }
    
    echo json_encode([
        'success' => true, 
        'message' => 'Stocks Tabelle erfolgreich erstellt und ' . count($stocks) . ' Aktien eingefügt!'
    ]);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Fehler beim Erstellen der Tabelle: ' . $e->getMessage()
    ]);
}
?>