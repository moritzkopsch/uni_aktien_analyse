<?php
require_once 'config.php';

// API configuration
$ALPHA_VANTAGE_API_KEY = '3GNMY707SDTBESAS';
$FMP_API_KEY = 'gngFoELto87OCztD6hAVwtXRT06YnyW3';

// Function to fetch data with cURL
function fetchData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        error_log("HTTP error fetching $url: $httpCode");
        return false;
    }
    
    return json_decode($response, true);
}

// Create stocks_data table if it doesn't exist
function createStocksDataTable($pdo) {
    $sql = "CREATE TABLE IF NOT EXISTS stocks_data (
        id INT AUTO_INCREMENT PRIMARY KEY,
        symbol VARCHAR(10) NOT NULL,
        name VARCHAR(255) NOT NULL,
        current_price DECIMAL(10,2) NOT NULL,
        change_value DECIMAL(10,2) DEFAULT 0,
        change_percentage DECIMAL(5,2) DEFAULT 0,
        open_price DECIMAL(10,2) DEFAULT 0,
        high_price DECIMAL(10,2) DEFAULT 0,
        low_price DECIMAL(10,2) DEFAULT 0,
        volume BIGINT DEFAULT 0,
        market_cap BIGINT DEFAULT 0,
        pe_ratio DECIMAL(8,2) DEFAULT NULL,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_symbol (symbol)
    )";
    
    try {
        $pdo->exec($sql);
        return true;
    } catch(PDOException $e) {
        error_log("Error creating stocks_data table: " . $e->getMessage());
        return false;
    }
}

// Get stock symbol from request
$symbol = $_GET['symbol'] ?? '';

if (empty($symbol)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Symbol parameter is required']);
    exit;
}

// Create table if needed
createStocksDataTable($pdo);

try {
    // First try Financial Modeling Prep API for real-time data
    $fmpUrl = "https://financialmodelingprep.com/api/v3/quote/{$symbol}?apikey={$FMP_API_KEY}";
    $stockData = fetchData($fmpUrl);
    
    if ($stockData && !empty($stockData) && isset($stockData[0])) {
        $data = $stockData[0];
        
        // Prepare data for database
        $stockInfo = [
            'symbol' => $data['symbol'],
            'name' => $data['name'] ?? $symbol,
            'current_price' => $data['price'] ?? 0,
            'change_value' => $data['change'] ?? 0,
            'change_percentage' => $data['changesPercentage'] ?? 0,
            'open_price' => $data['open'] ?? 0,
            'high_price' => $data['dayHigh'] ?? 0,
            'low_price' => $data['dayLow'] ?? 0,
            'volume' => $data['volume'] ?? 0,
            'market_cap' => $data['marketCap'] ?? 0,
            'pe_ratio' => $data['pe'] ?? null
        ];
        
    } else {
        // Fallback to Alpha Vantage API
        $alphaUrl = "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={$symbol}&apikey={$ALPHA_VANTAGE_API_KEY}";
        $alphaData = fetchData($alphaUrl);
        
        if ($alphaData && isset($alphaData['Global Quote'])) {
            $quote = $alphaData['Global Quote'];
            
            $stockInfo = [
                'symbol' => $quote['01. symbol'],
                'name' => $symbol, // Alpha Vantage doesn't provide company name in this endpoint
                'current_price' => floatval($quote['05. price']),
                'change_value' => floatval($quote['09. change']),
                'change_percentage' => floatval(str_replace('%', '', $quote['10. change percent'])),
                'open_price' => floatval($quote['02. open']),
                'high_price' => floatval($quote['03. high']),
                'low_price' => floatval($quote['04. low']),
                'volume' => intval($quote['06. volume']),
                'market_cap' => 0,
                'pe_ratio' => null
            ];
        } else {
            throw new Exception('Unable to fetch stock data from both APIs');
        }
    }
    
    // Insert or update stock data in database
    $sql = "INSERT INTO stocks_data (
        symbol, name, current_price, change_value, change_percentage,
        open_price, high_price, low_price, volume, market_cap, pe_ratio
    ) VALUES (
        :symbol, :name, :current_price, :change_value, :change_percentage,
        :open_price, :high_price, :low_price, :volume, :market_cap, :pe_ratio
    ) ON DUPLICATE KEY UPDATE
        name = VALUES(name),
        current_price = VALUES(current_price),
        change_value = VALUES(change_value),
        change_percentage = VALUES(change_percentage),
        open_price = VALUES(open_price),
        high_price = VALUES(high_price),
        low_price = VALUES(low_price),
        volume = VALUES(volume),
        market_cap = VALUES(market_cap),
        pe_ratio = VALUES(pe_ratio),
        last_updated = CURRENT_TIMESTAMP";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($stockInfo);
    
    // Return the stock data
    echo json_encode([
        'success' => true,
        'data' => $stockInfo,
        'message' => 'Stock data retrieved and saved successfully'
    ]);
    
} catch(Exception $e) {
    error_log("Error fetching stock details for {$symbol}: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching stock data: ' . $e->getMessage()
    ]);
}
?>