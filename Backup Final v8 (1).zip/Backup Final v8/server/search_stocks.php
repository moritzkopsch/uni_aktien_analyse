<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Nur GET-Anfragen erlaubt']);
    exit;
}

try {
    // Prüfe zuerst ob die stocks Tabelle existiert
    $checkTable = $pdo->query("SHOW TABLES LIKE 'stocks'");
    if ($checkTable->rowCount() == 0) {
        echo json_encode(['success' => false, 'message' => 'Stocks Tabelle existiert nicht. Bitte führen Sie init_database.php aus.']);
        exit;
    }
    
    $query = isset($_GET['q']) ? trim($_GET['q']) : '';
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    
    // Begrenze Limit auf maximal 50
    $limit = min($limit, 50);
    
    if (empty($query)) {
        // Wenn keine Suchanfrage, gib die ersten X Aktien zurück
        $stmt = $pdo->prepare("
            SELECT id, symbol, name, sector, country 
            FROM stocks 
            ORDER BY id ASC
            LIMIT ?
        ");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
    } else {
        // Suche nach Symbol oder Name (case-insensitive)
        $stmt = $pdo->prepare("
            SELECT id, symbol, name, sector, country 
            FROM stocks 
            WHERE symbol LIKE ? OR name LIKE ? 
            ORDER BY 
                CASE 
                    WHEN symbol LIKE ? THEN 1 
                    WHEN name LIKE ? THEN 2 
                    ELSE 3 
                END,
                symbol ASC
            LIMIT ?
        ");
        
        $searchTerm = '%' . $query . '%';
        $exactSymbol = $query . '%';
        $exactName = $query . '%';
        
        $stmt->bindValue(1, $searchTerm, PDO::PARAM_STR);
        $stmt->bindValue(2, $searchTerm, PDO::PARAM_STR);
        $stmt->bindValue(3, $exactSymbol, PDO::PARAM_STR);
        $stmt->bindValue(4, $exactName, PDO::PARAM_STR);
        $stmt->bindValue(5, $limit, PDO::PARAM_INT);
        $stmt->execute();
    }
    
    $stocks = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true, 
        'stocks' => $stocks,
        'count' => count($stocks)
    ]);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Datenbankfehler: ' . $e->getMessage()
    ]);
}
?>