<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_favorite') {
        $userId = $_SESSION['user_id'] ?? null;
        $stockName = $_POST['stock_name'] ?? '';
        $stockSymbol = $_POST['stock_symbol'] ?? '';
        
        if (!$userId) {
            echo json_encode(['success' => false, 'message' => 'Nicht angemeldet']);
            exit;
        }
        
        if (empty($stockName) || empty($stockSymbol)) {
            echo json_encode(['success' => false, 'message' => 'Name und Symbol sind erforderlich']);
            exit;
        }
        
        try {
            // Prüfe ob bereits in Favoriten
            $checkStmt = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND stock_symbol = ?");
            $checkStmt->execute([$userId, $stockSymbol]);
            
            if ($checkStmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Diese Aktie ist bereits in Ihren Favoriten!']);
                exit;
            }
            
            // Füge zu Favoriten hinzu
            $stmt = $pdo->prepare("INSERT INTO favorites (user_id, stock_name, stock_symbol) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $stockName, $stockSymbol]);
            
            echo json_encode(['success' => true, 'message' => 'Zu Favoriten hinzugefügt']);
            
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Datenbankfehler: ' . $e->getMessage()]);
        }
        
    } elseif ($action === 'remove_favorite') {
        $userId = $_SESSION['user_id'] ?? null;
        $favoriteId = $_POST['favorite_id'] ?? '';
        
        if (!$userId) {
            echo json_encode(['success' => false, 'message' => 'Nicht angemeldet']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("DELETE FROM favorites WHERE id = ? AND user_id = ?");
            $stmt->execute([$favoriteId, $userId]);
            
            echo json_encode(['success' => true, 'message' => 'Favorit entfernt']);
            
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Datenbankfehler: ' . $e->getMessage()]);
        }
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    if ($action === 'get_favorites') {
        $userId = $_SESSION['user_id'] ?? null;
        
        if (!$userId) {
            echo json_encode(['success' => false, 'message' => 'Nicht angemeldet']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM favorites WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$userId]);
            $favorites = $stmt->fetchAll();
            
            echo json_encode(['success' => true, 'favorites' => $favorites]);
            
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Datenbankfehler: ' . $e->getMessage()]);
        }
    }
}
?>