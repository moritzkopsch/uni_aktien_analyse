<?php
// ===== kleine helper (nur lokal, ohne api) =====
function _sma(array $v, int $p): ?float {
  $n = count($v); if ($n < $p) return null;
  return array_sum(array_slice($v, -$p)) / $p;
}
function _ema(array $v, int $p): ?float {
  $n = count($v); if ($n < $p) return null;
  $k = 2 / ($p + 1);
  $ema = array_sum(array_slice($v, 0, $p)) / $p;
  for ($i = $p; $i < $n; $i++) { $ema = $v[$i]*$k + $ema*(1-$k); }
  return $ema;
}
function _rsi(array $v, int $p=14): ?float {
  $n = count($v); if ($n <= $p) return null;
  $g=0; $l=0;
  for ($i=1;$i<=$p;$i++){ $d=$v[$i]-$v[$i-1]; if($d>0)$g+=$d; else $l-=$d; }
  $ag=$g/$p; $al=$l/$p;
  for ($i=$p+1;$i<$n;$i++){ $d=$v[$i]-$v[$i-1]; $G=$d>0?$d:0; $L=$d<0?-$d:0; $ag=($ag*($p-1)+$G)/$p; $al=($al*($p-1)+$L)/$p; }
  if ($al==0) return 100.0; $rs=$ag/$al; return 100-100/(1+$rs);
}
function _macd_hist(array $v, int $fast=12,int $slow=26,int $sig=9): ?float {
  $n=count($v); if ($n < max($fast,$slow)+$sig) return null;
  $macd=[];
  for($i=0;$i<$n;$i++){
    $ef=_ema(array_slice($v,0,$i+1),$fast);
    $es=_ema(array_slice($v,0,$i+1),$slow);
    $macd[] = ($ef!==null && $es!==null) ? $ef-$es : null;
  }
  $macd = array_values(array_filter($macd, fn($x)=>$x!==null));
  if (count($macd) < $sig) return null;
  $signal = _ema($macd, $sig);
  if ($signal===null) return null;
  $lastMacd = end($macd);
  return $lastMacd - $signal;
}
function _atr14(array $hi,array $lo,array $cl): ?float {
  $n=count($cl); if ($n<15) return null;
  $tr=[]; for($i=1;$i<$n;$i++){ $tr[] = max($hi[$i]-$lo[$i], abs($hi[$i]-$cl[$i-1]), abs($lo[$i]-$cl[$i-1])); }
  if (count($tr)<14) return null;
  // RMA
  $rma = array_sum(array_slice($tr,0,14))/14.0;
  for($i=14;$i<count($tr);$i++){ $rma = ($rma*13 + $tr[$i]) / 14.0; }
  return $rma;
}
function _label_from_score(float $v): string {
  if ($v < -5)   return 'SELL';
  if ($v < 0)    return 'HOLD (eher SELL)';
  if ($v < 0.5)  return 'HOLD';
  if ($v < 5)    return 'HOLD (eher BUY)';
  return 'BUY';
}

// ===== hauptfunktion: nimmt arrays -> gibt score/label/parts =====
function calc_tech_score_from_series(array $closes, array $highs, array $lows): array {
  $rsi   = _rsi($closes,14);
  $sma50 = _sma($closes,50);
  $hist  = _macd_hist($closes,12,26,9);
  $atr   = _atr14($highs,$lows,$closes);
  $lastC = (float)end($closes);

  $parts=[]; $sum=0; $cnt=0;

  // 1) RSI
  if ($rsi!==null){
    $sc=0; $txt='HOLD';
    if($rsi>=60){$sc=+1;$txt='BUY';}
    elseif($rsi>=50){$sc=+0.5;$txt='HOLD (eher BUY)';}
    elseif($rsi>40){$sc=0;$txt='HOLD';}
    elseif($rsi>30){$sc=-0.5;$txt='HOLD (eher SELL)';}
    else{$sc=-1;$txt='SELL';}
    $parts[]=['label'=>'RSI(14)','value'=>$rsi,'signal'=>$txt,'unit'=>$sc]; $sum+=$sc; $cnt++;
  } else { $parts[]=['label'=>'RSI(14)','value'=>null,'signal'=>'n/a','unit'=>0]; }

  // 2) MACD Hist
  if ($hist!==null){
    $sc=($hist>0?+1:($hist<0?-1:0)); $txt=($sc>0?'BUY':($sc<0?'SELL':'HOLD'));
    $parts[]=['label'=>'MACD Hist','value'=>$hist,'signal'=>$txt,'unit'=>$sc]; $sum+=$sc; $cnt++;
  } else { $parts[]=['label'=>'MACD Hist','value'=>null,'signal'=>'n/a','unit'=>0]; }

  // 3) Preis vs SMA50 (deadzone ±1%)
  if ($sma50!==null && $lastC>0){
    $rel=($lastC-$sma50)/$sma50;
    $sc=(abs($rel)<=0.01)?0:($rel>0?+1:-1);
    $txt=($sc>0?'BUY':($sc<0?'SELL':'HOLD'));
    $parts[]=['label'=>'Preis vs SMA50','value'=>$rel*100,'signal'=>$txt,'unit'=>$sc]; $sum+=$sc; $cnt++;
  } else { $parts[]=['label'=>'Preis vs SMA50','value'=>null,'signal'=>'n/a','unit'=>0]; }

  // 4) ATR filter (ruhig vs vola hoch)
  if ($atr!==null && $lastC>0){
    $vr=$atr/$lastC;
    $sc = ($vr>0.05 ? -0.5 : ($vr<0.02 ? +0.5 : 0));
    $txt= ($sc>0?'BUY (ruhig)':($sc<0?'SELL (vola hoch)':'HOLD'));
    $parts[]=['label'=>'ATR(14)/Close','value'=>$vr*100,'signal'=>$txt,'unit'=>$sc]; $sum+=$sc; $cnt++;
  } else { $parts[]=['label'=>'ATR(14)/Close','value'=>null,'signal'=>'n/a','unit'=>0]; }

  $score = $cnt ? ($sum/$cnt)*10.0 : 0.0;
  return [
    'score' => $score,
    'label' => _label_from_score($score),
    'parts' => $parts
  ];
}
