<?php
// schutz: datei nich 2x laden
if (defined('CHANGE_COMPANY_TO_STOCK_NAME_LOADED')) { return; }
define('CHANGE_COMPANY_TO_STOCK_NAME_LOADED', true);

// === db daten fuer stocks ===
const STOCKS_HOST    = 'localhost';
const STOCKS_DB      = 'pushgobt_uniprojektws';
const STOCKS_USER    = 'pushgobt_m1user';
const STOCKS_PASS    = 'C6IX2SooXYrU';
const STOCKS_PORT    = 3306;
const STOCKS_CHARSET = 'utf8mb4';

// pdo builder – nur ein mal
function stocks_pdo(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = 'mysql:host='.STOCKS_HOST.';port='.STOCKS_PORT.';dbname='.STOCKS_DB.';charset='.STOCKS_CHARSET;
    $pdo = new PDO($dsn, STOCKS_USER, STOCKS_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

// holt firmenname zu SYMBOL, case egal (UPPER(..))
function stockCompanyNameBySymbol(string $symbol): string {
    // eingabe putzen
    $symbol = trim($symbol);
    if ($symbol === '') return '';
    $pdo = stocks_pdo();
    // case-insensitiv suchen – sicher gegen collations-stress
    $st = $pdo->prepare('SELECT `name`, `symbol` FROM `stocks` WHERE UPPER(`symbol`) = UPPER(?) LIMIT 1');
    $st->execute([$symbol]);
    $row = $st->fetch();
    if (!$row) return '';
    $name = trim((string)($row['name'] ?? ''));
    $sym  = trim((string)($row['symbol'] ?? ''));
    return $name !== '' ? $name : ($sym !== '' ? $sym : '');
}

// ersetzt im uebergebenen array {COMPANY} per SYMBOL
function replaceCompanyInArrayBySymbol(array $items, string $symbol): array {
    $company = stockCompanyNameBySymbol($symbol);
    if ($company === '') {
        // nix gefundn -> wir lassen {COMPANY} stehen
        return $items;
    }
    foreach ($items as &$n) {
        // strings sicher stellen (sonnst php meckert)
        $n['headline'] = str_replace('{COMPANY}', $company, (string)($n['headline'] ?? ''));
        $n['body']     = str_replace('{COMPANY}', $company, (string)($n['body'] ?? ''));
    }
    unset($n);
    return $items;
}

// optionaler wrapper (falls du woanders alten namen benutzt hast)
if (!function_exists('replaceCompanyInArray')) {
    function replaceCompanyInArray(array $items, string $symbol): array {
        return replaceCompanyInArrayBySymbol($items, $symbol);
    }
}
