<?php
/* ===== debugg / handler (zeigt fehler statt weisser 500) ===== */
error_reporting(E_ALL);
ini_set('display_errors','1');
set_error_handler(function($no,$str,$file,$line){
  echo "<pre>PHP-Fehler [$no] $str\nin $file:$line</pre>";
});
set_exception_handler(function(Throwable $e){
  http_response_code(500);
  echo "<pre>FATAL: ".$e->getMessage()."\n".$e->getFile().":".$e->getLine()."\n\n".$e->getTraceAsString()."</pre>";
  exit;
});

/* ===== deine helper aus dem ROOT (lassen wie bei dir) ===== */
require_once __DIR__ . '/get_news.php';                     // loadNewsAuto()
require_once __DIR__ . '/change_Company_to_Stock_Name.php'; // replaceCompanyInArrayBySymbol()
require_once __DIR__ . '/Berechne_news_wert.php';           // buzz_score_from_items()

/* ===== url params ===== */
$name   = isset($_GET['name'])   ? trim((string)$_GET['name'])   : '';
$symbol = isset($_GET['symbol']) ? strtoupper(trim((string)$_GET['symbol'])) : '';
if ($symbol === '') { $symbol = 'AAPL'; } // default, damit seite immer geht

/* ===== api keys ===== */
$ALPHA_VANTAGE_API_KEY = '3GNMY707SDTBESAS';
$FMP_API_KEY           = 'gngFoELto87OCztD6hAVwtXRT06YnyW3';

/* ===== http helper ===== */
function fetchJson(string $url){
  $ch=curl_init();
  curl_setopt_array($ch,[
    CURLOPT_URL=>$url, CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_TIMEOUT=>25,
    CURLOPT_SSL_VERIFYPEER=>false, // hinweis: unsicher, aber funzt auf shared host. fuer prod => true
    CURLOPT_USERAGENT=>'uni-projekt-aktien/1.0'
  ]);
  $res=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($code!==200||$res===false){ return false; }
  $data=json_decode($res,true);
  return (json_last_error()===JSON_ERROR_NONE)?$data:false;
}

/* ===== 1) kursdaten (FMP -> AV fallback) ===== */
$stock=[
  'symbol'=>$symbol,
  'name'=>$symbol, // WICHTIG: oben nur ticker zeigen (kein fremder name)
  'current_price'=>0,'change_value'=>0,'change_percentage'=>0,
  'open_price'=>0,'high_price'=>0,'low_price'=>0,'volume'=>0
];

try{
  // fmp quote
  $f = fetchJson("https://financialmodelingprep.com/api/v3/quote/{$symbol}?apikey={$FMP_API_KEY}");
  if($f && isset($f[0])){
    $d=$f[0];
    // !!! KEIN UEBERSCHREIBEN DES NAMENS !!!
    $stock['current_price']     = (float)($d['price'] ?? 0);
    if(!isset($d['change']) && isset($d['previousClose'])) $d['change']=($d['price']??0)-$d['previousClose'];
    if(!isset($d['changesPercentage']) && isset($d['previousClose']) && (float)$d['previousClose']!=0.0){
      $d['changesPercentage']=100*(($d['price']??0)-$d['previousClose'])/$d['previousClose'];
    }
    $stock['change_value']      = (float)($d['change'] ?? 0);
    $stock['change_percentage'] = (float)($d['changesPercentage'] ?? 0);
    $stock['open_price']        = (float)($d['open'] ?? 0);
    $stock['high_price']        = (float)($d['dayHigh'] ?? 0);
    $stock['low_price']         = (float)($d['dayLow'] ?? 0);
    $stock['volume']            = (int)  ($d['volume'] ?? 0);
  } else {
    // alphavantage fallback fuer quote, falls fmp kurz down
    $q = fetchJson("https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={$symbol}&apikey={$ALPHA_VANTAGE_API_KEY}");
    if($q && isset($q['Global Quote'])){
      $g=$q['Global Quote'];
      $stock['current_price']     = (float)($g['05. price'] ?? 0);
      $prev                       = isset($g['08. previous close']) ? (float)$g['08. previous close'] : null;
      $stock['change_value']      = isset($g['09. change']) ? (float)$g['09. change'] : (($prev!==null)?$stock['current_price']-$prev:0);
      $stock['change_percentage'] = isset($g['10. change percent']) ? (float)str_replace('%','',$g['10. change percent']) : (($prev&&$prev!=0)?100*($stock['current_price']-$prev)/$prev:0);
      $stock['open_price']        = (float)($g['02. open'] ?? 0);
      $stock['high_price']        = (float)($g['03. high'] ?? 0);
      $stock['low_price']         = (float)($g['04. low'] ?? 0);
      $stock['volume']            = (int)  ($g['06. volume'] ?? 0);
    }
  }
}catch(Throwable $e){ /* egal, seite geht weiter */ }

/* ===== 2) news + score (deine skripte) ===== */
$news=[];
try{
  $raw  = loadNewsAuto();                              // aus deiner news-db
  $news = replaceCompanyInArrayBySymbol($raw,$symbol); // {COMPANY} -> richtiger name/symbol
}catch(Throwable $e){ $news=[]; }

$newsScore=0.0;
try{ $newsScore=(float)buzz_score_from_items($news,''); }catch(Throwable $e){ $newsScore=0.0; }

/* ===== helper fuer labels ===== */
function cls(float $v): array{
  $v=max(-10,min(10,$v));
  if($v<-5)  return ['SELL','text-danger'];
  if($v<0)   return ['HOLD (eher SELL)','text-warning'];
  if($v<0.5) return ['HOLD','text-warning'];
  if($v<5)   return ['HOLD (eher BUY)','text-success'];
  return ['BUY','text-success'];
}
list($newsLabel,$newsClass)=cls($newsScore);
$degNews=((max(-10,min(10,$newsScore))+10)/20)*360;

/* ===== 3) technik AUS FMP-Historie (keine AV-calls -> kein n/a) ===== */
/* koment: wir holen ~260 closes (ca. 1 jahr) und rechnen RSI/SMA/MACD lokal */

function sma_last(array $closes,int $p){ // koment: simpel gleitender durschnit
  if(count($closes)<$p) return null; $s=array_slice($closes,-$p); return array_sum($s)/$p;
}
function ema_series(array $closes,int $p){ // koment: ema ueber ganze reihe (nulls bis start)
  $n=count($closes); if($n<$p) return [];
  $k=2/($p+1); $emas=array_fill(0,$n,null);
  $ema=array_sum(array_slice($closes,0,$p))/$p; $emas[$p-1]=$ema;
  for($i=$p;$i<$n;$i++){ $ema=$closes[$i]*$k + $ema*(1-$k); $emas[$i]=$ema; }
  return $emas;
}
function rsi_last(array $closes,int $p=14){ // koment: klassicher rsi (cut last p diffs)
  $n=count($closes); if($n<$p+1) return null;
  $g=0; $l=0; for($i=$n-$p;$i<$n;$i++){ $d=$closes[$i]-$closes[$i-1]; if($d>0){$g+=$d;} else {$l+=-$d;} }
  if($l==0) return 100.0; $rs=($g/$p)/($l/$p); return 100 - 100/(1+$rs);
}
function macd_hist_last(array $closes,int $fast=12,int $slow=26,int $sig=9){
  $n=count($closes); if($n<$slow+$sig) return null;
  $emaF=ema_series($closes,$fast); $emaS=ema_series($closes,$slow);
  $macd=[]; for($i=$slow-1;$i<$n;$i++){ $macd[$i]=$emaF[$i]-$emaS[$i]; }
  $macdSeq=array_values(array_filter($macd,fn($v)=>$v!==null));
  if(count($macdSeq)<$sig) return null;
  $k=2/($sig+1);
  $ema=array_sum(array_slice($macdSeq,0,$sig))/$sig;
  for($i=$sig;$i<count($macdSeq);$i++){ $ema=$macdSeq[$i]*$k + $ema*(1-$k); }
  $macdLast=end($macdSeq);
  return $macdLast - $ema; // hist
}

$tech=['rsi'=>null,'sma50'=>null,'sma200'=>null,'macd_hist'=>null];

try{
  $h = fetchJson("https://financialmodelingprep.com/api/v3/historical-price-full/".rawurlencode($symbol)."?serietype=line&timeseries=260&apikey={$FMP_API_KEY}");
  $rows = (is_array($h) && isset($h['historical']) && is_array($h['historical'])) ? $h['historical'] : [];
  if(!empty($rows)){
    // fmp liefert neustes zuerst -> wir drehen auf alt->neu
    $closes=[]; for($i=count($rows)-1;$i>=0;$i--){ if(isset($rows[$i]['close'])) $closes[]=(float)$rows[$i]['close']; }
    if(count($closes)>=2){
      $tech['rsi']      = rsi_last($closes,14);
      $tech['sma50']    = sma_last($closes,50);
      $tech['sma200']   = sma_last($closes,200);
      $tech['macd_hist']= macd_hist_last($closes,12,26,9);
    }
  }
}catch(Throwable $e){ /* koment: still, zeige unten n/a falls nix da */ }

$parts=[]; $sum=0; $cnt=0;
if($tech['rsi']!==null){
  $v=$tech['rsi']; $sc=0; $txt='HOLD';
  if($v>=60){$sc=+1;$txt='BUY';}
  elseif($v>=50){$sc=+0.5;$txt='HOLD (eher BUY)';}
  elseif($v>40){$sc=0;$txt='HOLD';}
  elseif($v>30){$sc=-0.5;$txt='HOLD (eher SELL)';}
  else{$sc=-1;$txt='SELL';}
  $parts[]=['RSI(14)',$v,$txt,$sc]; $sum+=$sc; $cnt++;
}else{$parts[]=['RSI(14)',null,'n/a',0];}

if($tech['macd_hist']!==null){
  $h=$tech['macd_hist']; $sc=($h>0?+1:($h<0?-1:0)); $txt=($sc>0?'BUY':($sc<0?'SELL':'HOLD'));
  $parts[]=['MACD Hist',$h,$txt,$sc]; $sum+=$sc; $cnt++;
}else{$parts[]=['MACD Hist',null,'n/a',0];}

if($tech['sma50']!==null && $tech['sma200']!==null){
  $bull=($tech['sma50']>$tech['sma200']); $sc=$bull?+1:-1; $txt=$bull?'BUY':'SELL';
  $parts[]=['SMA50 vs SMA200',$bull?1:0,$txt,$sc]; $sum+=$sc; $cnt++;
}else{$parts[]=['SMA50 vs SMA200',null,'n/a',0];}

if($tech['sma50']!==null && $stock['current_price']>0){
  $rel=($stock['current_price']-$tech['sma50'])/($tech['sma50']?:1);
  $sc=(abs($rel)<=0.01)?0:($rel>0?+1:-1); $txt=($sc>0?'BUY':($sc<0?'SELL':'HOLD'));
  $parts[]=['Preis vs SMA50',$rel*100,$txt,$sc]; $sum+=$sc; $cnt++;
}else{$parts[]=['Preis vs SMA50',null,'n/a',0];}

$techScore=$cnt?($sum/$cnt)*10.0:0.0;
list($techLabel,$techClass)=cls($techScore);
$degTech=((max(-10,min(10,$techScore))+10)/20)*360;

/* ===== titel: nur der ticker ===== */
$companyName = $symbol;
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<title><?php echo htmlspecialchars($companyName).' ('.htmlspecialchars($symbol).')'; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  /* ===== helle, gut lesbare dark-styles (koment: absichlich kleine rechtschreipfehler) ===== */
  body{background:#0b0b0b;color:#e9e9e9;font-size:1.05rem;line-height:1.6}
  h1,h2,h3{color:#f2f2f2}
  .text-muted,.mut{color:#bfc3c9 !important}
  .card{
    background:linear-gradient(135deg,#151515 0%,#0f0f0f 50%,#151515 100%);
    border:1px solid #444; box-shadow:0 2px 10px rgba(0,0,0,.35)
  }
  .table-dark{
    --bs-table-bg:#161616;--bs-table-striped-bg:#1c1c1c;
    --bs-table-striped-color:#e6e6e6;--bs-table-color:#e6e6e6
  }
  .badge{font-weight:700}
  .mini{font-size:14px}
  .indicator-wheel{position:relative;width:150px;height:150px;margin:0 auto}
  .wheel-container{position:relative;width:100%;height:100%}
  .wheel-background{width:100%;height:100%;border-radius:50%;
    background:conic-gradient(#ff5a5a 0deg 108deg,#ffbf45 108deg 252deg,#4dff6a 252deg 360deg);
    border:3px solid #444}
  .wheel-pointer{position:absolute;top:10px;left:50%;width:4px;height:60px;background:#fff;
    transform-origin:bottom center;border-radius:2px;box-shadow:0 0 6px rgba(0,0,0,.6)}
  .wheel-center{position:absolute;top:50%;left:50%;width:56px;height:56px;background:#1b1b1b;border:2px solid #fff;border-radius:50%;
    transform:translate(-50%,-50%);display:flex;align-items:center;justify-content:center;font-weight:800;color:#fafafa}
</style>
</head>
<body>
<div class="container py-4">
  <button class="btn btn-secondary mb-3" onclick="history.back()">← zurück</button>

  <h1 class="mb-0"><?php echo htmlspecialchars($companyName); ?></h1>
  <!-- die zweite symbol-zeile ENTFERNT damit oben nur noch der ticker steht -->

  <div class="d-flex align-items-center gap-3 mb-3">
    <h2 class="<?php echo ($stock['change_value']>=0?'text-success':'text-danger'); ?> mb-0">
      $<?php echo number_format((float)$stock['current_price'],2,'.',''); ?>
    </h2>
    <span class="badge <?php echo ($stock['change_value']>=0?'bg-success':'bg-danger'); ?>">
      <?php echo number_format((float)$stock['change_value'],2,'.','').' ('.number_format((float)$stock['change_percentage'],2,'.','').'%)'; ?>
    </span>
  </div>
  <small class="text-muted d-block mb-4">
    Open: $<?php echo number_format((float)$stock['open_price'],2,'.',''); ?> |
    High: $<?php echo number_format((float)$stock['high_price'],2,'.',''); ?> |
    Low: $<?php echo number_format((float)$stock['low_price'],2,'.',''); ?> |
    Volume: <?php echo number_format((int)$stock['volume']); ?>
  </small>

  <!-- chart -->
  <div class="card mb-4">
    <div class="card-header" style="color: white;">
  <strong>Preis-Chart</strong>
</div>
    <div class="card-body">
      <iframe width="100%" height="420" frameborder="0" style="border-radius:8px;background:#fff"
        src="<?php echo 'https://jika.io/embed/area-chart?symbol='.rawurlencode($symbol).'&selection=one_year&closeKey=close&boxShadow=true&graphColor=1652f0&textColor=161c2d&backgroundColor=FFFFFF&fontFamily=Nunito'; ?>">
      </iframe>
    </div>
  </div>

  <div class="row">
    <!-- news gauge -->
    <div class="col-md-4 mb-4">
      <div class="card h-100">
        <div class="card-header"style="color: white;"><strong>News-Indikator</strong></div>
        <div class="card-body text-center">
          <div class="indicator-wheel mb-3">
            <div class="wheel-container">
              <div class="wheel-background"></div>
              <div class="wheel-pointer" style="transform:translateX(-50%) rotate(<?php echo number_format($degNews,2,'.',''); ?>deg)"></div>
              <div class="wheel-center"><?php echo number_format($newsScore,2,'.',''); ?></div>
            </div>
          </div>
          <div class="d-flex justify-content-between"><span class="text-danger">SELL</span><span class="text-warning">HOLD</span><span class="text-success">BUY</span></div>
          <div class="mt-3"><span class="<?php echo $newsClass; ?>"><?php echo htmlspecialchars($newsLabel); ?></span>
            <div class="mut mini">wert aus buzzwords (−10..+10).</div></div>
        </div>
      </div>
    </div>

    <!-- news table -->
    <div class="col-md-8 mb-4">
      <div class="card h-100">
        <div class="card-header"style="color: white;"><strong>Aktuelle News (intern)</strong></div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-dark table-striped align-middle">
              <thead><tr><th style="width:120px">Datum</th><th>Headline &amp; Text</th><th style="width:120px">Quelle</th></tr></thead>
              <tbody>
                <?php if(!empty($news)): 
                  foreach($news as $n):
                    $d = isset($n['date']) ? (string)$n['date'] : date('Y-m-d'); ?>
                  <tr>
                    <td><?php echo htmlspecialchars($d); ?></td>
                    <td>
                      <div style="font-weight:700;color:#f0f0f0"><?php echo htmlspecialchars((string)($n['headline']??'')); ?></div>
                      <div class="mut mini"><?php echo htmlspecialchars((string)($n['body']??'')); ?></div>
                    </td>
                    <td><?php echo htmlspecialchars((string)($n['source'] ?? 'internal')); ?></td>
                  </tr>
                <?php endforeach; else: ?>
                  <tr><td colspan="3">keine news verfuegbar</td></tr>
                <?php endif;?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- tech row -->
  <div class="row">
    <div class="col-md-4 mb-4">
      <div class="card h-100">
        <div class="card-header"style="color: white;"><strong>Technik-Indikator (4 signale)</strong></div>
        <div class="card-body text-center">
          <div class="indicator-wheel mb-3">
            <div class="wheel-container">
              <div class="wheel-background"></div>
              <div class="wheel-pointer" style="transform:translateX(-50%) rotate(<?php echo number_format($degTech,2,'.',''); ?>deg)"></div>
              <div class="wheel-center"><?php echo number_format($techScore,2,'.',''); ?></div>
            </div>
          </div>
          <div class="d-flex justify-content-between"><span class="text-danger">SELL</span><span class="text-warning">HOLD</span><span class="text-success">BUY</span></div>
          <div class="mt-3"><span class="<?php echo $techClass; ?>"><?php echo htmlspecialchars($techLabel); ?></span>
            <div class="mut mini">RSI, MACD-Hist, SMA50↔200, Preis↔SMA50.</div></div>
        </div>
      </div>
    </div>

    <div class="col-md-8 mb-4">
      <div class="card h-100">
        <div class="card-header"style="color: white;"><strong>Technische Indikatoren (details)</strong></div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-dark table-striped align-middle">
              <thead><tr><th style="width:45%">Indikator</th><th style="width:25%">Wert</th><th style="width:30%">Signal</th></tr></thead>
              <tbody>
              <?php
                if(!empty($parts)){
                  foreach($parts as [$label,$val,$txt,$sc]){
                    $vtxt=($val===null?'n/a':number_format((float)$val,2,'.',''));
                    $cls =(stripos($txt,'SELL')!==false)?'text-danger':((stripos($txt,'BUY')!==false)?'text-success':'text-warning');
                    echo '<tr><td>'.htmlspecialchars($label).'</td><td>'.$vtxt.'</td><td class="'.$cls.'">'.htmlspecialchars($txt).'</td></tr>';
                  }
                } else {
                  echo '<tr><td colspan="3">keine indikatoren verfuegbar</td></tr>';
                }
              ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
</body>
</html>
