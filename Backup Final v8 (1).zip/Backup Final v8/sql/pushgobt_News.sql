-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 20, 2025 at 10:36 AM
-- Server version: 11.4.8-MariaDB-cll-lve
-- PHP Version: 8.3.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pushgobt_News`
--

-- --------------------------------------------------------

--
-- Table structure for table `news_templates`
--

CREATE TABLE `news_templates` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'Primärschlüssel',
  `headline` varchar(300) NOT NULL COMMENT 'Überschrift, enthält {COMPANY}',
  `body` text DEFAULT NULL COMMENT 'Text, optional; kann {COMPANY} enthalten',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Universelle News-Templates mit Platzhalter {COMPANY}';

--
-- Dumping data for table `news_templates`
--

INSERT INTO `news_templates` (`id`, `headline`, `body`, `created_at`, `updated_at`) VALUES
(1, 'Analysten heben Ausblick: {COMPANY} erhält upgrade to buy', 'Nach einem record quarter hebt ein großes Haus die Einstufung auf. Positive surprise und margin expansion treiben den Optimismus.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(2, '{COMPANY} meldet beats estimates und guidance raise', 'Stärker als erwartete Zahlen; raises outlook für das Gesamtjahr und betont accelerating growth in Kernbereichen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(3, '{COMPANY} sichert regulatory approval für neues Produkt', 'Die approval ermöglicht den Markteintritt früher als geplant; pipeline strength und major partnership bekräftigt.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(4, 'Rekordzahlen bei {COMPANY}: record revenue und profitability milestone', 'Operative Effizienz und cost synergies führen zu operating leverage und positive free cash flow.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(5, 'Dividende rauf: {COMPANY} announces dividend increase', 'Vorstand beschließt raises dividend; net cash position bleibt komfortabel, buyback-Programm wird geprüft.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(6, '{COMPANY} gewinnt government tender in Schlüsselmarkt', 'Secures mega contract über mehrere Jahre; orders surge erwartet, backlog wächst.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(7, 'Starker Auftragseingang: {COMPANY} mit bookings strength', 'Kunden verlängern Verträge – contract extension und renewal rate up; visibility improves.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(8, '{COMPANY} expandiert international – expansion approved', 'Lizenz/permit erhalten; license granted in neuer Region, double-digit growth anvisiert.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(9, 'Produktlaunch bei {COMPANY} ahead of schedule', 'Neues Produkt startet früher; positive momentum, market share gains und cross-sell success erwartet.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(10, 'Rating bestätigt: {COMPANY} rating reaffirmed buy', 'Analysten verweisen auf healthy balance sheet und unit economics improve.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(11, 'Kostenprogramm greift: {COMPANY} zeigt productivity gains', 'efficiency program und cost cutting erhöhen die Margen – stabilizing trends im Kerngeschäft.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(12, '{COMPANY} mit strong demand im Kerngeschäft', 'Orders improving, ahead of peers; guidance maintained high end.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(13, 'Cashflow dreht: {COMPANY} cash flow positive', 'Sequentielle Verbesserung; operational excellence steigert ARPU – arpu up und churn down.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(14, 'Partnerschaft gemeldet: {COMPANY} schließt major partnership', 'Gemeinsame Entwicklung eröffnet tailwinds ahead; pricing power erwartet.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(15, '{COMPANY} erweitert Pilot: pilot expanded nach erfolgreicher Testphase', 'Kundenfeedback positiv; steady growth und early signs of recovery in Nebenlinien.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(16, 'Warnzeichen bei {COMPANY}: guidance cut nach earnings miss', 'Unternehmensführung senkt Ausblick; margin erosion und traffic declines belasten die Entwicklung.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(17, '{COMPANY} im Fokus: lawsuit und regulatory setback gemeldet', 'Ein class action Verfahren wurde eingereicht; accounting investigation nicht ausgeschlossen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(18, 'Sicherheitsvorfall: data breach bei {COMPANY}', 'Berichteter Vorfall könnte zu regulatory fines likely führen; forensische Untersuchung läuft.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(19, 'Verzögerungen bei {COMPANY}: delay im Produktlaunch', 'production bottleneck und component constraints; shipment delays möglich.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(20, 'Analysten reagieren: downgrade to sell für {COMPANY}', 'Whistleblower claims und governance concerns drücken auf die Stimmung; restates earnings nicht ausgeschlossen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(21, '{COMPANY} senkt Prognose: guidance lowered nach soft demand', 'pricing pressure und inventory build; execution risk bleibt erhöht.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(22, 'Rückrufdrohung: major recall bei {COMPANY} möglich', 'supplier dispute und capacity issues könnten zu order cancellations führen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(23, 'Liquidität unter Druck: liquidity concerns bei {COMPANY}', 'debt covenant risk steigt; credit downgrade erwogen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(24, 'Cyberangriff: ransomware attack auf {COMPANY}', 'major data leak kann nicht ausgeschlossen werden; service outage führte zu downtime incident.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(25, 'Kostenseite belastet: cost overrun bei {COMPANY}', 'operating deleverage und lower utilization drücken die Marge; profit warning steht im Raum.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(26, 'Marktumfeld schwierig: underperform – store closures bei {COMPANY}', 'slower growth und customer loss; promo activity up im Wettbewerb.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(27, 'Ermittlung eingeleitet: sec investigation zu {COMPANY}', 'auditor flags führten zu einer Prüfung; material weakness möglich.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(28, 'Projektverzug: project slippage bei {COMPANY}', 'ahead of schedule verfehlt; execution risk und transition period verlängern die Umsetzung.', '2025-09-18 12:20:38', '2025-09-18 12:21:18'),
(29, 'Personalabbau: layoffs bei {COMPANY}', 'restructuring charges und impairment belasten das Quartal; guidance narrowed lower.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(30, 'Exportthema: sanctions risk trifft {COMPANY}', 'export restrictions und permit denied gefährden Lieferketten und Topline.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(31, '{COMPANY} startet internes Wohn-Pilotprojekt', 'Ziel ist Mitarbeiterbindung; operative Details folgen im Laufe des Quartals.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(32, 'Management von {COMPANY} bestätigt bisherigen Jahresfahrplan', 'Reiterates outlook ohne Anpassungen; Monitoring der Marktlage bleibt bestehen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(33, 'Technologie-Update bei {COMPANY}', 'Neue Features in begrenzter Verfügbarkeit; Kundenfeedback wird gesammelt.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(34, '{COMPANY} erweitert Schulungsprogramme für Partner', 'Fokus auf Enablement und Support; Effekte erwartet man mittelfristig.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(35, 'Vertragsverlängerung: {COMPANY} erneuert Serviceabkommen', 'Laufzeit und Konditionen unverändert; Auswirkungen auf Prognose neutral.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(36, 'Standort-News: {COMPANY} optimiert Flächen', 'Umzug einzelner Teams ohne Einfluss auf die Produktion; Effizienzpotenziale werden geprüft.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(37, 'Produktpflege: {COMPANY} liefert kleinere Updates', 'Bugfixes und Stabilitätsverbesserungen; Rollout in Wellen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(38, 'Messeauftritt: {COMPANY} präsentiert Lösungen', 'Kunden- und Partnergespräche; konkrete Deals wurden nicht genannt.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(39, 'Standardmeldung: {COMPANY} gibt Terminplan bekannt', 'Quartalstermine und Events veröffentlicht; keine Guidance-Änderung.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(40, 'Interne Prozesse: {COMPANY} passt Berichtswesen an', 'Ziel ist bessere Transparenz; Kennzahlen bleiben unverändert.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(41, 'Community: {COMPANY} unterstützt Bildungsinitiative', 'CSR-Programm wird fortgeführt; keine finanziellen Auswirkungen erwartet.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(42, 'Compliance-Update bei {COMPANY}', 'Routinemäßige Anpassungen; keine regulatorischen Auffälligkeiten gemeldet.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(43, 'IT-Wartung: {COMPANY} führt geplante Updates durch', 'Kurzzeitige Einschränkungen möglich; Services anschließend wie gewohnt.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(44, 'Partnernetz: {COMPANY} konsolidiert Reseller', 'Schwerpunkt auf Qualität; Lieferfähigkeit bleibt stabil.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(45, 'Standardhinweis: {COMPANY} aktualisiert Datenschutzhinweise', 'Regelmäßige Revision; keine Änderungen an Produkten oder Preisen.', '2025-09-18 12:20:38', '2025-09-18 12:20:38'),
(46, '{COMPANY} erhält price target hike bei führendem Analysehaus', 'Analysten verweisen auf above-consensus Entwicklung und expanding margin in den Kernsegmenten.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(47, 'Starkes Signal: {COMPANY} with top line beat und positive surprise', 'Wachstum über Erwartung; profit guidance up und Visibility improves.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(48, '{COMPANY} kündigt initiates buyback Programm an', 'Erhöhte Kapitalrückführung geplant; net cash position bleibt solide, dividend increase möglich.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(49, 'Lizenz erteilt: license granted für {COMPANY} in neuer Region', 'International expansion startet; double-digit growth im Blick.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(50, 'Partnerschaft fix: major partnership stärkt {COMPANY}', 'Cross-sell success erwartet, backlog und bookings strength ziehen an.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(51, '{COMPANY} meldet accelerating growth im Cloud-Geschäft', 'Unit economics improve; operating leverage sichtbar.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(52, 'Rekordtrend setzt sich fort: record earnings bei {COMPANY}', 'Ahead of schedule Meilensteine; profitability milestone erreicht.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(53, 'Outperformance bestätigt: {COMPANY} rated outperform', 'Market share gains und pricing power unterstützen die Story.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(54, '{COMPANY} hebt raises outlook nach starkem Quartal', 'Guidance lifted; positive momentum in allen Produktlinien.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(55, 'Starker Auftragseingang: orders surge bei {COMPANY}', 'Renewal rate up und net retention above 120% gemeldet.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(56, 'Favorable ruling: Gericht stärkt Position von {COMPANY}', 'Weniger Rechtsrisiken; tailwinds ahead für die Pipeline.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(57, 'Supply easing hilft {COMPANY} beim Hochfahren', 'Inventory normalized; stabilizing trends bei Margen.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(58, 'Cashflow dreht positiv: cash flow positive bei {COMPANY}', 'Sequential improvement und utilization improves sichtbar.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(59, 'Rating bestätigt: rating reaffirmed buy für {COMPANY}', 'Healthy balance sheet und resilience der Nachfrage.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(60, 'Pilot erfolgreich: pilot expanded bei {COMPANY}', 'Early signs of recovery auch in kleineren Sparten.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(61, 'Produktstart: new product launch bei {COMPANY} ahead of schedule', 'Kundenfeedback stark; inline to above Erwartungen.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(62, 'Starke Nachfrage: strong demand beflügelt {COMPANY}', 'Guidance maintained high end; ARPU up und churn down.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(63, 'Börsenhöchststand: all-time high bei {COMPANY}', 'Record revenue und operational excellence treiben die Bewertung.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(64, 'Ausblick gesenkt: {COMPANY} mit guidance lowered nach earnings miss', 'Margin erosion und traffic declines belasten das Quartal.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(65, 'Ermittlungen: accounting investigation möglich bei {COMPANY}', 'Auditor flags und governance concerns verunsichern Anleger.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(66, 'Rechtsstreit: lawsuit trifft {COMPANY} in wichtigem Markt', 'Class action anhängig; regulatory fines likely können folgen.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(67, 'Produktion stockt: production bottleneck bei {COMPANY}', 'Component constraints führen zu shipment delays.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(68, 'Downgrade: {COMPANY} now downgrade to sell', 'Weaker than expected Wachstum und competition intensifies.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(69, 'Cybervorfall: major data leak bei {COMPANY}', 'Ransomware attack nicht ausgeschlossen; service outage gemeldet.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(70, 'Warnhinweis: profit warning bei {COMPANY}', 'Cost overrun und operating deleverage drücken die Marge.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(71, 'Standorte schließen: store closures bei {COMPANY}', 'Customer loss und softer demand; promo activity up im Markt.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(72, 'Finanzierung angespannt: liquidity concerns bei {COMPANY}', 'Debt covenant risk steigt; credit downgrade denkbar.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(73, 'Rückruf: major recall droht {COMPANY}', 'Supplier dispute und capacity issues im Fokus.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(74, 'Leichte Schwäche: slight miss bei {COMPANY}', 'Cautious commentary und seasonal weakness genannt.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(75, 'Starker Gegenwind: fx headwinds und pricing pressure bei {COMPANY}', 'Inventory build belastet kurzfristig.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(76, 'Miss auf Umsatz: miss on revenue bei {COMPANY}', 'Guidance narrowed lower; utilization down.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(77, 'Sperre: export restrictions treffen {COMPANY}', 'Sanctions risk erhöht regulatorischen Druck.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(78, 'Leitung geht: ceo resigns abruptly bei {COMPANY}', 'Transition period; execution risk erhöht.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(79, 'Neubewertung: restates earnings möglich bei {COMPANY}', 'Material weakness im internen Kontrollsystem geprüft.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(80, 'Börsenrisiko: delisting notice für {COMPANY}', 'Kapitalmaßnahmen und underperform im letzten Halbjahr.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(82, '{COMPANY} eröffnet Besucherzentrum am Hauptstandort', 'Ziel ist Markenpräsenz; operative Kennzahlen unverändert.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(83, 'Community-Förderung: {COMPANY} unterstützt lokale Projekte', 'CSR-Programm ausgeweitet; keine Guidance-Änderung.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(84, '{COMPANY} standardisiert interne Tools für Teams', 'Rollout schrittweise; Produkt-Roadmap bleibt stabil.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(85, 'Terminankündigung: {COMPANY} plant Capital Markets Day', 'Agenda folgt; keine finanziellen Effekte vorab.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(86, 'Partnertraining erweitert: {COMPANY} schult Reseller', 'Enablement im Fokus; Vertriebskanäle bleiben konstant.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(87, 'Rebranding einzelner Services bei {COMPANY}', 'Benennung angepasst; kein Einfluss auf Verträge.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(88, 'IT-Betrieb: {COMPANY} führt planmäßige Wartung durch', 'Kurzzeitige Einschränkungen möglich; Services anschließend normal.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(89, 'Neue Büroräume: {COMPANY} optimiert Flächennutzung', 'Mitarbeiterumzug ohne Einfluss auf Produktion.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(90, 'Datenrichtlinien aktualisiert: {COMPANY} passt Hinweise an', 'Reguläre Revision; keine Produktänderungen.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(91, 'Messepräsenz: {COMPANY} zeigt Lösungen auf Branchen-Event', 'Kundengespräche, jedoch ohne konkrete Vertragszahlen.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(92, 'Pilot zur Mitarbeiterbindung bei {COMPANY}', 'Wohn- oder Mobilitätsangebote; Effekte werden evaluiert.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(93, 'Routine: {COMPANY} bestätigt bisherigen Jahresfahrplan', 'Keine Änderungen der Termine; Monitoring der Lage fortgesetzt.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(94, 'Programm für Nachwuchs: {COMPANY} startet Trainee-Kohorte', 'Langfristige Personalentwicklung; neutrale Finanzwirkung.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(95, 'Nachhaltigkeit: {COMPANY} veröffentlicht ESG-Update', 'Kennzahlen berichtet; ohne neue finanzielle Ziele.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(96, 'Dokumentation: {COMPANY} modernisiert internes Berichtswesen', 'Transparenz steigt; Prognose bleibt unberührt.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(97, 'Service-Hinweis: {COMPANY} bündelt Support-Kanäle', 'Einheitliches Ticket-System; Reaktionszeiten unverändert.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(98, 'Kundenkommunikation: {COMPANY} passt AGB sprachlich an', 'Rechtliche Klarstellung; kein Pricing-Impact.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(99, 'Standard-Release: {COMPANY} liefert Bugfix-Rollup', 'Stabilität und Performance leicht verbessert.', '2025-09-18 12:21:18', '2025-09-18 12:21:18'),
(100, 'Roadmap-Reminder: {COMPANY} bestätigt Quartalsmeilensteine', 'Plan liegt im Zeitrahmen; keine Guidance-News.', '2025-09-18 12:21:18', '2025-09-18 12:21:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news_templates`
--
ALTER TABLE `news_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_news_headline` (`headline`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news_templates`
--
ALTER TABLE `news_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Primärschlüssel', AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
