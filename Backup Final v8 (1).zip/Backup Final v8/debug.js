// Debug Script - füge dies am Ende von script.js hinzu oder als separate Datei

// Test Server Verbindung
async function testServerConnection() {
    try {
        console.log('Teste Server Verbindung...');
        const response = await fetch('server/test.php');
        const result = await response.json();
        console.log('Server Test Ergebnis:', result);
        
        if (result.status === 'success') {
            console.log('✅ Server läuft korrekt');
            console.log('👥 Anzahl User in DB:', result.user_count);
        } else {
            console.error('❌ Server Fehler:', result.message);
        }
    } catch (error) {
        console.error('❌ Verbindungsfehler:', error);
        console.log('Mögliche Ursachen:');
        console.log('- PHP Server nicht gestartet');
        console.log('- Falsche Server URL');
        console.log('- CORS Probleme');
    }
}

// CSS Debug
function debugCSS() {
    console.log('CSS Debug Info:');
    const body = document.body;
    const computedStyle = window.getComputedStyle(body);
    console.log('Body Background:', computedStyle.background);
    console.log('Body Color:', computedStyle.color);
    
    // Prüfe ob CSS geladen wurde
    const styleSheets = document.styleSheets;
    console.log('Geladene Stylesheets:', styleSheets.length);
    
    for (let i = 0; i < styleSheets.length; i++) {
        console.log(`Stylesheet ${i}:`, styleSheets[i].href);
    }
}

// Auto-Debug beim Laden
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔧 Debug Modus aktiviert');
    debugCSS();
    testServerConnection();
});