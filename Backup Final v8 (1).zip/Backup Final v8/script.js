// Globale Variablen
let currentUser = null;
let currentFavorites = [];

document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatus();
});

function checkLoginStatus() {
    fetch('server/auth.php?action=check_session')
        .then(response => response.json())
        .then(result => {
            if (result.success && result.user) {
                currentUser = result.user;
                updateNavbar(true);
                // Lade Favoriten neu wenn auf Favorites-Seite
                if (window.location.pathname.includes('favorites.html')) {
                    loadFavorites();
                }
            } else {
                updateNavbar(false);
            }
        })
        .catch(error => console.error('Session check error:', error));
}

function updateNavbar(isLoggedIn) {
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const userInfo = document.getElementById('userInfo');
    const userId = document.getElementById('userId');

    if (isLoggedIn && currentUser) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (registerBtn) registerBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'inline-block';
        if (userInfo) {
            userInfo.style.display = 'inline-block';
            if (userId) userId.textContent = currentUser.id;
        }
    } else {
        if (loginBtn) loginBtn.style.display = 'inline-block';
        if (registerBtn) registerBtn.style.display = 'inline-block';
        if (logoutBtn) logoutBtn.style.display = 'none';
        if (userInfo) userInfo.style.display = 'none';
    }
}

function showLogin() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    if (loginForm) loginForm.style.display = 'block';
    if (registerForm) registerForm.style.display = 'none';
}

function showRegister() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    if (registerForm) registerForm.style.display = 'block';
    if (loginForm) loginForm.style.display = 'none';
}

function hideAuth() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    if (loginForm) loginForm.style.display = 'none';
    if (registerForm) registerForm.style.display = 'none';
}

async function viewDetails(stockName, stockSymbol) {

    try {
        const response = await fetch(
            `server/stock_details.php?symbol=${encodeURIComponent(stockSymbol)}`
        );

        if (!response.ok) {
            throw new Error("Fehler beim Abruf der Stock-Details");
        }

        const data = await response.json();
        console.log("Stock Details:", data);

        // Wenn erfolgreich, weiterleiten
        if (data.success) {
            window.location.href = `tester_einzel_aktie.php?name=${encodeURIComponent(stockName)}&symbol=${encodeURIComponent(stockSymbol)}`;
        }
    } catch (error) {
        console.error("Fetch Error:", error);
    }
}


async function login(event) {
    event.preventDefault();
    
    // Verbesserte Element-Suche mit Fehlerbehandlung
    const usernameElement = document.getElementById('loginUsername');
    const passwordElement = document.getElementById('loginPassword');
    
    if (!usernameElement) {
        console.error('loginUsername Element nicht gefunden');
        alert('Login-Formular nicht korrekt geladen. Bitte Seite neu laden.');
        return;
    }
    
    if (!passwordElement) {
        console.error('loginPassword Element nicht gefunden');
        alert('Login-Formular nicht korrekt geladen. Bitte Seite neu laden.');
        return;
    }
    
    const email = usernameElement.value;
    const password = passwordElement.value;
    
    if (!email || !password) {
        alert('Bitte E-Mail und Passwort eingeben.');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'login');
    formData.append('email', email); // KORREKTUR: 'email' statt 'username'
    formData.append('password', password);
    
    try {
        const response = await fetch('server/auth.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            currentUser = result.user;
            updateNavbar(true);
            hideAuth();
            alert('Login erfolgreich!');
            
            // Lade Favoriten neu wenn auf Favorites-Seite
            if (window.location.pathname.includes('favorites.html')) {
                loadFavorites();
            }
        } else {
            alert('Login fehlgeschlagen: ' + result.message);
        }
    } catch (error) {
        console.error('Login Fehler:', error);
        alert('Login Fehler: ' + error.message);
    }
}

async function register(event) {
    event.preventDefault();
    
    const usernameElement = document.getElementById('registerUsername');
    const passwordElement = document.getElementById('registerPassword');
    
    if (!usernameElement || !passwordElement) {
        alert('Registrierungs-Formular nicht korrekt geladen. Bitte Seite neu laden.');
        return;
    }
    
    const email = usernameElement.value;
    const password = passwordElement.value;
    
    if (!email || !password) {
        alert('Bitte E-Mail und Passwort eingeben.');
        return;
    }
    
    // Validiere E-Mail Format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Bitte geben Sie eine gültige E-Mail-Adresse ein.');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'register');
    formData.append('email', email); // KORREKTUR: 'email' statt 'username'
    formData.append('password', password);
    
    try {
        const response = await fetch('server/auth.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Registrierung erfolgreich! Prüfen Sie Ihre E-Mails für den Verifizierungscode.');
            hideAuth();
            // Weiterleitung zur Verifizierungsseite
            if (result.redirect) {
                window.location.href = result.redirect;
            }
        } else {
            alert('Registrierung fehlgeschlagen: ' + result.message);
        }
    } catch (error) {
        console.error('Registrierung Fehler:', error);
        alert('Registrierung Fehler: ' + error.message);
    }
}

async function logout() {
    try {
        const response = await fetch('server/auth.php', {
            method: 'POST',
            body: new URLSearchParams({ action: 'logout' })
        });
        
        const result = await response.json();
        
        if (result.success) {
            currentUser = null;
            currentFavorites = [];
            updateNavbar(false);
            alert('Erfolgreich abgemeldet!');
            
            // Wenn auf Favorites-Seite, zeige "nicht angemeldet" Nachricht
            if (window.location.pathname.includes('favorites.html')) {
                loadFavorites();
            } else {
                window.location.href = 'index.html';
            }
        } else {
            alert('Logout fehlgeschlagen: ' + result.message);
        }
    } catch (error) {
        console.error('Logout Fehler:', error);
        alert('Logout Fehler: ' + error.message);
    }
}

async function addToFavorites(stockName, stockSymbol) {
    if (!currentUser) {
        alert('Sie müssen angemeldet sein, um Favoriten hinzuzufügen.');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'add_favorite');
    formData.append('stock_name', stockName);
    formData.append('stock_symbol', stockSymbol);
    
    try {
        const response = await fetch('server/favorites.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Zu Favoriten hinzugefügt!');
            // Lade Favoriten neu wenn auf Favorites-Seite
            if (window.location.pathname.includes('favorites.html')) {
                loadFavorites();
            }
        } else {
            alert('Fehler: ' + result.message);
        }
    } catch (error) {
        console.error('Fehler beim Hinzufügen zu Favoriten:', error);
        alert('Fehler beim Hinzufügen zu Favoriten: ' + error.message);
    }
}

async function addFavoriteFromSearch() {
    // Alte Implementierung für Kompatibilität
    const symbolInput = document.getElementById('symbolInput');
    const nameInput = document.getElementById('nameInput');
    
    if (!symbolInput || !nameInput) {
        console.error('Symbol oder Name Input nicht gefunden');
        return;
    }
    
    const symbol = symbolInput.value.trim();
    const name = nameInput.value.trim();
    
    if (!symbol || !name) {
        alert('Bitte Symbol und Name eingeben');
        return;
    }
    
    await addToFavorites(name, symbol);
    
    // Felder leeren
    symbolInput.value = '';
    nameInput.value = '';
}

async function loadFavorites() {
    if (!currentUser) {
        const favoritesList = document.getElementById('favoritesList');
        if (favoritesList) {
            favoritesList.innerHTML = `
                <div class="alert alert-warning" style="background-color: rgba(255, 193, 7, 0.8); border-color: rgba(255, 193, 7, 0.8); color: #000;">
                    Sie müssen angemeldet sein, um Ihre Favoriten zu sehen.
                </div>
            `;
        }
        currentFavorites = [];
        return;
    }

    try {
        const response = await fetch('server/favorites.php?action=get_favorites');
        const result = await response.json();

        if (result.success) {
            currentFavorites = result.favorites;
            displayFavorites(result.favorites);
        } else {
            console.error('Fehler beim Laden der Favoriten:', result.message);
        }
    } catch (error) {
        console.error('Fehler beim Laden der Favoriten:', error);
    }
}

function displayFavorites(favorites) {
    const favoritesList = document.getElementById('favoritesList');
    if (!favoritesList) {
        console.error('favoritesList Element nicht gefunden');
        return;
    }
    
    let emptyMessage = document.getElementById('emptyMessage');
    
    // Falls emptyMessage nicht existiert, erstelle es
    if (!emptyMessage) {
        emptyMessage = document.createElement('div');
        emptyMessage.id = 'emptyMessage';
        emptyMessage.className = 'alert alert-info';
        emptyMessage.style.cssText = 'background-color: rgba(13, 202, 240, 0.8); border-color: rgba(13, 202, 240, 0.8); color: #000;';
        favoritesList.appendChild(emptyMessage);
    }
    
    if (favorites.length === 0) {
        emptyMessage.style.display = 'block';
        emptyMessage.textContent = 'Keine Favoriten vorhanden. Fügen Sie welche hinzu!';
        
        // Entferne alle anderen Elemente außer der leeren Nachricht
        const children = Array.from(favoritesList.children);
        children.forEach(child => {
            if (child.id !== 'emptyMessage') {
                child.remove();
            }
        });
        return;
    }
    
    emptyMessage.style.display = 'none';
    
    // Entferne alle Kinder außer emptyMessage
    const children = Array.from(favoritesList.children);
    children.forEach(child => {
        if (child.id !== 'emptyMessage') {
            child.remove();
        }
    });
    
    favorites.forEach(favorite => {
        const favoriteDiv = document.createElement('div');
        favoriteDiv.className = 'favorite-item';
        favoriteDiv.innerHTML = `
            <div>
                <h5>${favorite.stock_name}</h5>
                <small>${favorite.stock_symbol}</small>
            </div>
            <div class="favorite-buttons">
                <button class="btn btn-sm" onclick="viewDetails('${favorite.stock_name}', '${favorite.stock_symbol}')" style="background: linear-gradient(45deg, #4169E1 0%, #1E90FF 100%); border-color: #4169E1; color: white; font-weight: bold; border-radius: 20px;">Details</button>
                <button class="btn btn-sm" onclick="removeFavorite(${favorite.id})" style="background: linear-gradient(45deg, #ff4444 0%, #cc3333 100%); border-color: #ff4444; color: white; font-weight: bold; border-radius: 20px;">Entfernen</button>
            </div>
        `;
        favoritesList.appendChild(favoriteDiv);
    });
}

async function removeFavorite(favoriteId) {
    const formData = new FormData();
    formData.append('action', 'remove_favorite');
    formData.append('favorite_id', favoriteId);
    
    try {
        const response = await fetch('server/favorites.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Favorit entfernt!');
            loadFavorites(); // Lade Favoriten neu
        } else {
            alert('Fehler beim Entfernen: ' + result.message);
        }
    } catch (error) {
        console.error('Fehler beim Entfernen des Favoriten:', error);
        alert('Fehler beim Entfernen des Favoriten: ' + error.message);
    }
}

// Zusätzliche Hilfsfunktionen für Stocks-Seite
async function searchStocks() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;
    
    const query = searchInput.value.trim();
    const searchResults = document.getElementById('searchResults');
    const searchResultsList = document.getElementById('searchResultsList');
    
    if (!searchResults || !searchResultsList) return;
    
    if (query.length < 2) {
        searchResults.style.display = 'none';
        return;
    }
    
    try {
        const response = await fetch(`server/search_stocks.php?q=${encodeURIComponent(query)}&limit=10`);
        const data = await response.json();
        
        if (data.success && data.stocks) {
            searchResultsList.innerHTML = '';
            
            data.stocks.forEach(stock => {
                const resultItem = document.createElement('div');
                resultItem.className = 'search-result-item';
                
                // Prüfe ob bereits in Favoriten
                const isInFavorites = currentFavorites.some(fav => fav.stock_symbol === stock.symbol);
                const buttonStyle = isInFavorites ? 
                    'background: #666; color: #ccc; cursor: not-allowed;' : 
                    'background: linear-gradient(45deg, #90EE90 0%, #7FDD7F 100%); color: #000; box-shadow: 0 2px 4px rgba(144, 238, 144, 0.3);';
                const buttonText = isInFavorites ? '✓ Bereits hinzugefügt' : '+ Zu Favoriten hinzufügen';
                const buttonIcon = isInFavorites ? '' : '<i class="fas fa-heart"></i> ';
                
                resultItem.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center p-3" style="border-bottom: 1px solid #333;">
                        <div>
                            <span class="search-result-symbol fw-bold text-success">${stock.symbol}</span>
                            <div class="text-white fs-6">${stock.name}</div>
                            <small class="text-muted">${stock.sector || ''} - ${stock.country || ''}</small>
                        </div>
                        <div class="d-flex gap-2">
                            <button class="btn btn-sm" onclick="viewDetails('${stock.name}', '${stock.symbol}')" 
                                style="background: linear-gradient(45deg, #4169E1 0%, #1E90FF 100%); color: white; border-radius: 15px;">
                                <i class="fas fa-info-circle"></i> Details
                            </button>
                            <button class="btn btn-sm fw-bold" onclick="addToFavorites('${stock.name}', '${stock.symbol}')" 
                                style="${buttonStyle} border-radius: 15px; min-width: 160px;" ${isInFavorites ? 'disabled' : ''}>
                                ${buttonIcon}${buttonText}
                            </button>
                        </div>
                    </div>
                `;
                searchResultsList.appendChild(resultItem);
            });
            
            searchResults.style.display = 'block';
        } else {
            searchResults.style.display = 'none';
        }
    } catch (error) {
        console.error('Suchfehler:', error);
        searchResults.style.display = 'none';
    }
}

function clearSearch() {
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    
    if (searchInput) searchInput.value = '';
    if (searchResults) searchResults.style.display = 'none';
}