<?php
// fehler an (zum debuggen)
error_reporting(E_ALL);
ini_set('display_errors','1');

// schutz: nich 2x laden
if (!defined('BERECHNE_NEWS_WERT_LOADED')) { define('BERECHNE_NEWS_WERT_LOADED', true); }

// fuer optionalen {COMPANY}-ersatz per symbol
require_once __DIR__.'/change_Company_to_Stock_Name.php'; // kommentare absichltich mit fehlern

// ---- DB daten fuer buzzwörds ----
const BW_HOST = 'localhost';
const BW_DB   = 'pushgobt_words';
const BW_USER = 'pushgobt_m1user';
const BW_PASS = 'C6IX2SooXYrU';
const BW_PORT = 3306;
const BW_CHAR = 'utf8mb4';

// pdo fuer buzzwords
function bw_pdo(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = 'mysql:host='.BW_HOST.';port='.BW_PORT.';dbname='.BW_DB.';charset='.BW_CHAR;
    $pdo = new PDO($dsn, BW_USER, BW_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

// buzzwords laden -> map [term_lower => score_int]
function loadBuzzwords(PDO $pdo): array {
    $rows = $pdo->query("SELECT term, score_int FROM buzzwords WHERE term <> ''")->fetchAll();
    if (!$rows) return [];
    $map = [];
    foreach ($rows as $r) {
        $term = trim(mb_strtolower((string)$r['term'], 'UTF-8')); // alles klein
        if ($term === '') continue;
        $map[$term] = (int)$r['score_int'];
    }
    return $map;
}

// text normlaisirn
function normalizeText(string $s): string {
    $s = mb_strtolower($s, 'UTF-8');
    $s = preg_replace('~[^\p{L}\p{Nd}]+~u', ' ', $s);
    $s = preg_replace('~\s+~u', ' ', $s);
    return trim($s);
}

// score rechnen ueber ALLE news (headline+body)
function calcBuzzScore(array $items, array $buzz): array {
    if (empty($items) || empty($buzz)) return ['hits'=>0,'sum'=>0,'avg'=>0.0];

    // alle texte zusammen
    $big = '';
    foreach ($items as $n) {
        $big .= ' '.((string)($n['headline'] ?? '')).' '.((string)($n['body'] ?? ''));
    }
    $norm = normalizeText($big);

    $totalHits = 0; $totalScore = 0;

    // lange phrasen zuerst
    $terms = array_keys($buzz);
    usort($terms, fn($a,$b) => mb_strlen($b,'UTF-8') <=> mb_strlen($a,'UTF-8'));

    foreach ($terms as $t) {
        $score = $buzz[$t];
        $pat   = '~\b' . preg_quote($t, '~') . '\b~u';
        if (preg_match_all($pat, $norm, $m)) {
            $cnt = count($m[0]);
            if ($cnt > 0) {
                $totalHits  += $cnt;
                $totalScore += $cnt * $score;
                $norm = preg_replace($pat, ' ', $norm); // doppel zaehlung vermeiden
            }
        }
    }
    $avg = ($totalHits > 0) ? ($totalScore / $totalHits) : 0.0;
    return ['hits'=>$totalHits,'sum'=>$totalScore,'avg'=>$avg];
}

// ====== PUBLIC API ======
// nimmt schon geladene news ($items) und optional ein symbol zum ersetzen
function buzz_score_from_items(array $items, string $symbol = ''): float {
    try {
        if ($symbol !== '') { $items = replaceCompanyInArrayBySymbol($items, $symbol); }
        if (empty($items)) return 0.0;
        $buzz = loadBuzzwords(bw_pdo());
        if (empty($buzz)) return 0.0;
        $res = calcBuzzScore($items, $buzz);
        return (float)($res['avg'] ?? 0.0);
    } catch (Throwable $e) {
        return 0.0; // sicherheits netz: immer ne zahl zuruek
    }
}

// ====== direkter test: gibt nur den wert (oder json) ======
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    require_once __DIR__.'/get_news.php';
    $symbol = $_GET['symbol'] ?? $_GET['s'] ?? $_GET['ticker'] ?? '';
    $items  = loadNewsAuto();
    $val    = buzz_score_from_items($items, (string)$symbol);
    if (!empty($_GET['json'])) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['avg_score'=>$val], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
    } else {
        header('Content-Type: text/plain; charset=utf-8');
        echo number_format($val, 6, '.', '');
    }
}
